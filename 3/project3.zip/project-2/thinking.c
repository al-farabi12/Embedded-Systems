/**
 * simulate thinking
 */

#include <stdio.h>

void thinking(int sleep_time) 
{
	//printf("thinking for %d seconds",sleep_time);
	sleep(sleep_time);
}
