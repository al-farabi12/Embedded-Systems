#include <pthread.h>
#include <stdio.h>

int fib[100];
long	 num;
int i=0;
int k=2;
void *fib_p(void *p);
void *fib_c(void *p);

int main(){
	fib[0]=0;
	fib[1]=1;
	pthread_t parent; //thread identifiers

	//create the thread parent
	pthread_create(&parent,NULL,fib_p,NULL);
	pthread_join(parent,NULL);
	printf("\n");



}

void *fib_p(void *p)
{

	printf("How many fibonacci number do you need?");
	scanf("%lu", &num);
	pthread_t child; //thread id

	//create the thread child
	pthread_create(&child, NULL, fib_c, NULL);
	pthread_join(child, NULL);

	for(i;i<num;i++)
	{
		printf("%i  ", fib[i]);



	}	


	pthread_exit(0);
}

void *fib_c(void *p)
{
	for(k ;k<num ;k++)
	{
		fib[k]=fib[k-1]+fib[k-2];
	

	}


pthread_exit(0);
}
