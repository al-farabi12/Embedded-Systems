#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int x[100000]; //X COORDS
int y[100000]; // Y COORDS
int in_cir = 0; //HOW MANY POINTS IN CIRCLE WILL BE

void *thread_f(void *p); //THREAD FUNCTION

int main()
{
	srand(time(0));
	int d = rand()%10000;
	long r = d;
	int i;
	float pi;
	for (i = 0; i<d; i++)
	{
		x[i] = rand()%10000 - 5000;
		y[i] = rand()%10000 - 5000;
	}
	printf("Amount of points: %lu \n", r);
	pthread_t t; //	THREAD ID
	pthread_create(&t, NULL, thread_f, (void*)r); //CREATING THREADS
	pthread_join(t, NULL); //WAITING TO FINISH
	pi = 4.0*in_cir/r;
	printf("The pi is equal to %f \n", pi);
	
}

void *thread_f(void *p)
{
	int i;
	int k;
	long d = (long)p;
	for (i = 0; i<d; i++)
	{
		k = sqrt(x[i]*x[i] + y[i]*y[i]);
		if (k<5000)
		{ 
			in_cir++;
		}
	}
	printf("Amount of points inside the circle: %i\n", in_cir);
	pthread_exit(0);
}

