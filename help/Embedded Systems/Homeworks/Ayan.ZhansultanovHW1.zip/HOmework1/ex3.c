#include <pthread.h>
#include <stdio.h>
int num;
int k=1;
int i=2;



void *prime(void*p); //thread call

int main(){
	scanf("%i", &num);
	
	pthread_t out_t; //thread identifier
	printf("Prime numbers are:\n");
	//create the thread output
	pthread_create(&out_t,NULL,prime,NULL);
	pthread_join(out_t,NULL);
	printf("Done. \n");
	
return 0;	
}

void *prime(void*p)
{

	for(i=2;i<num;i++)
	{
		int n=0;
		for(k=1;k<i;k++)
		{
			if(i%k==0)
			{
			n++;
			}
		

		}

		if(n<2)
		{
		printf("%i\n", i);
		}

	}
pthread_exit(0);
}
