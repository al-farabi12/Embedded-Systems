#include <pthread.h>
#include <stdio.h>

int max=-9999;
int ave=0;
int min=9999;
int arg[100];
int i=0;

void *average(void*p); //thread calls
void *maximum(void*p);
void *minimum(void*p);

int main(){
	
	char c= '1';
		
	while(c!='\n'){
		scanf("%i%c",&arg[i], &c);
		i++;
	}

	pthread_t max_t; //thread identifiers
	pthread_t min_t;
	pthread_t ave_t;
	
	//create the thread maximum
	pthread_create(&max_t,NULL,maximum,NULL);
	pthread_join(max_t,NULL);
	printf("Maximum value is: %i \n", max);

	//create the thread minimum
	pthread_create(&min_t,NULL,minimum,NULL);
	pthread_join(min_t,NULL);
	printf("Minimum value is: %i \n", min);

	//create the thread average
	pthread_create(&ave_t,NULL,average,NULL);
	pthread_join(ave_t,NULL);
	printf("Average value is: %i \n",ave);




	return 0;
}

//Thread max_t wil be controlled in this function
void *maximum(void*p)
{
	int k=0;
	for(k=0;k<i;k++)
	{
	
		if(arg[k]>max)
		{
			max=arg[k];
		}

	}
pthread_exit(0);

}
//Thread min_t wil be controlled in this function
void *minimum(void*p)
{
	int k=0;
	for(k=0;k<i;k++)
	{
	
		if(arg[k]<min)
		{
			min=arg[k];
		}

	}
pthread_exit(0);

}

//Thread ave_t will be controlled here

void *average(void*p)
{
int sum=0;
int k=0;
	for(k; k<i; k++)
	{
	sum=sum+arg[k];



	}
ave=sum/k;
pthread_exit(0);
}














